package com.dopamine.blessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
